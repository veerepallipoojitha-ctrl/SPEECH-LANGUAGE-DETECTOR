const SpeechRecognition =
    window.SpeechRecognition ||
    window.webkitSpeechRecognition;

let recognition;


const languageNames = {

    "en-US": "English",

    "ta-IN": "Tamil",

    "hi-IN": "Hindi",

    "te-IN": "Telugu",

    "ml-IN": "Malayalam",

    "kn-IN": "Kannada",

    "fr-FR": "French",

    "de-DE": "German",

    "es-ES": "Spanish"

};


if (SpeechRecognition) {

    recognition = new SpeechRecognition();

    recognition.continuous = false;

    recognition.interimResults = false;


    recognition.onstart = function () {

        document.getElementById("status").innerText =
            "🎤 Listening... Please speak.";

    };


    recognition.onresult = function (event) {

        const transcript =
            event.results[0][0].transcript;


        document.getElementById("speechText").value =
            transcript;


        document.getElementById("status").innerText =
            "✅ Speech recognized successfully.";

    };


    recognition.onerror = function (event) {

        document.getElementById("status").innerText =
            "Error: " + event.error;

    };


    recognition.onend = function () {

        document.getElementById("status").innerText =
            "Recognition stopped.";

    };

}


document
    .getElementById("language")
    .addEventListener("change", function () {

        const language =
            this.value;


        const name =
            languageNames[language];


        document.getElementById("languageResult")
            .innerText = name;

});


function startRecognition() {

    if (!recognition) {

        alert(
            "Speech recognition is not supported. Please use Google Chrome."
        );

        return;

    }


    const language =
        document.getElementById("language").value;


    recognition.lang =
        language;


    try {

        recognition.start();

    }
    catch (error) {

        console.log(error);

    }

}


function stopRecognition() {

    if (recognition) {

        try {

            recognition.stop();

        }
        catch (error) {

            console.log(error);

        }

    }

}


function clearText() {

    document.getElementById("speechText").value = "";

    document.getElementById("status").innerText =
        "Select a language and start speaking.";

}